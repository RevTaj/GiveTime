-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 04 Mars 2025 à 08:23
-- Version du serveur :  5.7.11
-- Version de PHP :  7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `db-pottijar`
--

-- --------------------------------------------------------

--
-- Structure de la table `sae203_admin`
--

CREATE TABLE `sae203_admin` (
  `id_admin` smallint(10) UNSIGNED NOT NULL,
  `nomAdmin` varchar(50) NOT NULL,
  `prenomAdmin` varchar(50) NOT NULL,
  `mailAdmin` varchar(20) NOT NULL,
  `loginAdmin` varchar(50) NOT NULL,
  `mdpAdmin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `sae203_admin`
--

INSERT INTO `sae203_admin` (`id_admin`, `nomAdmin`, `prenomAdmin`, `mailAdmin`, `loginAdmin`, `mdpAdmin`) VALUES
(1, 'Pottin', 'Jarode', 'admin@gmail.com', 'pottijar', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(2, 'Revelle', 'Sacha', 'Sachaadmin@gmail.com', 'revelsac', '8a51851ae82a470fe9a89c52a7fb0fb8c8dda544');

-- --------------------------------------------------------

--
-- Structure de la table `sae203_cours`
--

CREATE TABLE `sae203_cours` (
  `id_Cours` smallint(10) UNSIGNED NOT NULL,
  `TitreCours` varchar(50) NOT NULL,
  `Enseignant_id` smallint(10) UNSIGNED NOT NULL,
  `tag` varchar(50) NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `sae203_cours`
--

INSERT INTO `sae203_cours` (`id_Cours`, `TitreCours`, `Enseignant_id`, `tag`, `Description`) VALUES
(24, 'Sciences', 4, 'Sciences', 'Ce cours explore les principes de base des sciences '),
(25, 'Informatique', 4, 'Informatique', 'Ce cours aborde les bases de l\'informatique'),
(27, 'Francais ', 5, 'Français ', 'Ce cours se concentre sur la langue francaise.'),
(28, 'Economie et Societe', 5, 'Économie et Société', 'Ce cours examine les principes economiques');

-- --------------------------------------------------------

--
-- Structure de la table `sae203_enseignant`
--

CREATE TABLE `sae203_enseignant` (
  `id_Enseignant` smallint(10) UNSIGNED NOT NULL,
  `nomEnseignant` varchar(50) NOT NULL,
  `prenomEnseignant` varchar(50) NOT NULL,
  `mailEnseignant` varchar(50) NOT NULL,
  `loginEnseignant` varchar(50) NOT NULL,
  `mdpEnseignant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `sae203_enseignant`
--

INSERT INTO `sae203_enseignant` (`id_Enseignant`, `nomEnseignant`, `prenomEnseignant`, `mailEnseignant`, `loginEnseignant`, `mdpEnseignant`) VALUES
(4, 'Robert', 'Lucas', 'Robertlucas@gmail.com', 'RoberL', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(5, 'Girard', 'Adrien', 'AdrienGirard@gmail.com', 'GirarA', '8e0389c9b8e3ac03041508d863089992ccbace34'),
(6, 'RObert', 'Julien', 'root@root.com', 'RobertJ', '7c4a8d09ca3762af61e59520943dc26494f8941b'),
(7, 'Robert', 'Lucas', 'LucasRobert@univ.fr', 'RobertL', 'b50c014a26d2b8afa49737f05a185072a3ba9c56');

-- --------------------------------------------------------

--
-- Structure de la table `sae203_etudiant`
--

CREATE TABLE `sae203_etudiant` (
  `id_etudiant` smallint(10) UNSIGNED NOT NULL,
  `nomEtudiant` varchar(50) NOT NULL,
  `prenomEtudiant` varchar(50) NOT NULL,
  `mailEtudiant` varchar(50) NOT NULL,
  `loginEtudiant` varchar(50) NOT NULL,
  `mdpEtudiant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `sae203_etudiant`
--

INSERT INTO `sae203_etudiant` (`id_etudiant`, `nomEtudiant`, `prenomEtudiant`, `mailEtudiant`, `loginEtudiant`, `mdpEtudiant`) VALUES
(2, 'Martin', 'Nicolas', 'MArtinNicolas@gmail.com', 'MartiN', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(3, 'Bernard', 'Hugo', 'BernardHugo@gmail.com', 'BernaH', '3cd969896e49a6d3326acf33f0c2d8cc38b0d06a'),
(4, 'Lefevbre', 'Julien', 'julien@gmail.com', 'LefevJ', '1694cbdee37ee9faee0cf770ff474621513375db'),
(5, 'Julien', 'J', 'root@root2.com', 'JulienJ', '824b182f29d2bf96c20a3a16c271d63477f217ae'),
(6, 'Julien', 'Morrat', 'MorratJ@univ.fr', 'JulienM', 'a09450a18509f07c73289551eac71fc7f3f3743c');

-- --------------------------------------------------------

--
-- Structure de la table `sae203_inscription`
--

CREATE TABLE `sae203_inscription` (
  `id_inscription` smallint(10) UNSIGNED NOT NULL,
  `cours_id` smallint(10) UNSIGNED NOT NULL,
  `etudiant_id` smallint(10) UNSIGNED NOT NULL,
  `date_debut` date NOT NULL,
  `progression` float NOT NULL,
  `date_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contenu de la table `sae203_inscription`
--

INSERT INTO `sae203_inscription` (`id_inscription`, `cours_id`, `etudiant_id`, `date_debut`, `progression`, `date_fin`) VALUES
(83, 28, 2, '2025-03-04', 0, '2025-03-04');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `sae203_admin`
--
ALTER TABLE `sae203_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `sae203_cours`
--
ALTER TABLE `sae203_cours`
  ADD PRIMARY KEY (`id_Cours`),
  ADD KEY `Enseignant_id` (`Enseignant_id`);

--
-- Index pour la table `sae203_enseignant`
--
ALTER TABLE `sae203_enseignant`
  ADD PRIMARY KEY (`id_Enseignant`);

--
-- Index pour la table `sae203_etudiant`
--
ALTER TABLE `sae203_etudiant`
  ADD PRIMARY KEY (`id_etudiant`);

--
-- Index pour la table `sae203_inscription`
--
ALTER TABLE `sae203_inscription`
  ADD PRIMARY KEY (`id_inscription`),
  ADD KEY `etudiant_id` (`etudiant_id`),
  ADD KEY `cours_id` (`cours_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `sae203_admin`
--
ALTER TABLE `sae203_admin`
  MODIFY `id_admin` smallint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `sae203_cours`
--
ALTER TABLE `sae203_cours`
  MODIFY `id_Cours` smallint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `sae203_enseignant`
--
ALTER TABLE `sae203_enseignant`
  MODIFY `id_Enseignant` smallint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `sae203_etudiant`
--
ALTER TABLE `sae203_etudiant`
  MODIFY `id_etudiant` smallint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `sae203_inscription`
--
ALTER TABLE `sae203_inscription`
  MODIFY `id_inscription` smallint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `sae203_cours`
--
ALTER TABLE `sae203_cours`
  ADD CONSTRAINT `SAE203_Cours_ibfk_1` FOREIGN KEY (`Enseignant_id`) REFERENCES `sae203_enseignant` (`id_Enseignant`);

--
-- Contraintes pour la table `sae203_inscription`
--
ALTER TABLE `sae203_inscription`
  ADD CONSTRAINT `SAE203_Inscription_ibfk_1` FOREIGN KEY (`etudiant_id`) REFERENCES `sae203_etudiant` (`id_etudiant`),
  ADD CONSTRAINT `SAE203_Inscription_ibfk_2` FOREIGN KEY (`cours_id`) REFERENCES `sae203_cours` (`id_Cours`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
