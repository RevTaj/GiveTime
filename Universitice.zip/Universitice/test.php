<?php 

try {
    $db = new PDO('mysql:host=localhost;dbname=db-pottijar', 'root', 'root');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

?>