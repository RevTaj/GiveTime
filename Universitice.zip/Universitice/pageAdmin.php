<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/admin.css">
    <title>Admin - Gestion des enseignants</title>
</head>
<body>
    <h1>Gestion des enseignants</h1> <!-- Titre centré en haut -->
    <a href="deconnexion.php" class="logout">Se déconnecter</a>
    <?php
    session_start();
    // Afficher les erreurs pour le débogage
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    if ($_SESSION['authentification'] == false || $_SESSION['Permission'] < 4) {
        header('Location: Erreur.php');
        exit;
    }

    include("test.php");
    $id_Admin = $_SESSION['Identifiant'];

    // Récupérer le prénom de l'utilisateur depuis la base de données
    $query = $db->prepare("SELECT prenomAdmin,nomAdmin FROM SAE203_Admin WHERE id_admin = :id_Admin");
    $query->execute(array(':id_Admin' => $id_Admin));
    $result = $query->fetch(PDO::FETCH_ASSOC);
    $prenomEnseignant = $result['prenomAdmin'];
    $nomEnseignant = $result['nomAdmin'];
    
    // Ajouter un enseignant
    if (isset($_POST['add_prof'])) {
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $login = $_POST['login'];
        $mdp = sha1($_POST['mdp']);

        // Vérification des données
        if (empty($nom) || empty($prenom) || empty($email) || empty($login) || empty($mdp)) {
            echo "Tous les champs sont obligatoires.";
        } else {
            $sqlInsertProf = "INSERT INTO SAE203_Enseignant (nomEnseignant, prenomEnseignant, mailEnseignant, loginEnseignant, mdpEnseignant)
                              VALUES (:nom, :prenom, :email, :login, :mdp)";
            $insertProf = $db->prepare($sqlInsertProf);
            $result = $insertProf->execute(array(
                ':nom' => $nom,
                ':prenom' => $prenom,
                ':email' => $email,
                ':login' => $login,
                ':mdp' => $mdp
            ));
            
            if ($result) {
                echo "Enseignant ajouté avec succès.";
            } else {
                echo "Erreur lors de l'ajout de l'enseignant.";
            }
        }
    }

    // Modifier un enseignant
    if (isset($_POST['update_prof'])) {
        $id_Prof = $_POST['id_Prof'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $login = $_POST['login'];
        if (!empty($_POST['mdp'])) {
            $mdp = sha1($_POST['mdp']);
        } else {
            $mdp = null;
        }

        // Vérification des données
        if (empty($nom) || empty($prenom) || empty($email) || empty($login)) {
            echo "Tous les champs sont obligatoires, sauf le mot de passe.";
        } else {
            $sqlUpdateProf = "UPDATE SAE203_Enseignant SET nomEnseignant = :nom, prenomEnseignant = :prenom, mailEnseignant = :email, loginEnseignant = :login";
            if ($mdp) {
                $sqlUpdateProf .= ", mdpEnseignant = :mdp";
            }
            $sqlUpdateProf .= " WHERE id_Enseignant = :id_Prof";
            $updateProf = $db->prepare($sqlUpdateProf);
            $params = array(
                ':nom' => $nom,
                ':prenom' => $prenom,
                ':email' => $email,
                ':login' => $login,
                ':id_Prof' => $id_Prof
            );
            if ($mdp) {
                $params[':mdp'] = $mdp;
            }
            $result = $updateProf->execute($params);
            
            if ($result) {
                echo "Enseignant modifié avec succès.";
            } else {
                echo "Erreur lors de la modification de l'enseignant.";
            }
        }
    }

    // Supprimer un enseignant et ses cours et inscriptions associées
    if (isset($_POST['delete_prof'])) {
        $id_Prof = $_POST['id_Prof'];

        // Supprimer les inscriptions associées aux cours de l'enseignant
        $sqlDeleteInscriptions = "DELETE FROM SAE203_Inscription WHERE cours_id IN (SELECT id_Cours FROM SAE203_Cours WHERE Enseignant_id = :id_Prof)";
        $deleteInscriptions = $db->prepare($sqlDeleteInscriptions);
        $deleteInscriptions->execute(array(':id_Prof' => $id_Prof));

        // Supprimer les cours de l'enseignant
        $sqlDeleteCours = "DELETE FROM SAE203_Cours WHERE Enseignant_id = :id_Prof";
        $deleteCours = $db->prepare($sqlDeleteCours);
        $deleteCours->execute(array(':id_Prof' => $id_Prof));

        // Supprimer l'enseignant
        $sqlDeleteProf = "DELETE FROM SAE203_Enseignant WHERE id_Enseignant = :id_Prof";
        $deleteProf = $db->prepare($sqlDeleteProf);
        $deleteProf->execute(array(':id_Prof' => $id_Prof));

        echo "Enseignant et ses cours et inscriptions associées supprimés avec succès.";
    }

    // Récupérer la liste des enseignants
    $query = $db->prepare("SELECT * FROM SAE203_Enseignant");
    $query->execute();
    $enseignants = $query->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="container">
    <div class="welcome-message">
                <?php
                // Afficher le message de bienvenue
                echo "Bonjour " . htmlspecialchars($prenomEnseignant) ." ".htmlspecialchars($nomEnseignant). " !" ;
                ?>
    </div>
        <div class="content">
            
            <div class="left-section">
                <h2>Liste des enseignants :</h2>
                <ul>
                    <?php foreach ($enseignants as $enseignant): ?>
                        <li>
                            <?= htmlspecialchars($enseignant['prenomEnseignant'] . ' ' . $enseignant['nomEnseignant']); ?>
                            <form method="post" action="" style="display:inline;">
                                <input type="hidden" name="id_Prof" value="<?= $enseignant['id_Enseignant']; ?>">
                                <input type="submit" name="delete_prof" value="Supprimer">
                            </form>
                            <button onclick="document.getElementById('editForm-<?= $enseignant['id_Enseignant']; ?>').style.display='block'">Modifier</button>
                            <div id="editForm-<?= $enseignant['id_Enseignant']; ?>" style="display:none;">
                                <form method="post" action="">
                                    <input type="hidden" name="id_Prof" value="<?= $enseignant['id_Enseignant']; ?>">
                                    <p>
                                        <label for="nom">Nom :</label>
                                        <input type="text" name="nom" id="nom" value="<?= htmlspecialchars($enseignant['nomEnseignant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="prenom">Prénom :</label>
                                        <input type="text" name="prenom" id="prenom" value="<?= htmlspecialchars($enseignant['prenomEnseignant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="email">Email :</label>
                                        <input type="email" name="email" id="email" value="<?= htmlspecialchars($enseignant['mailEnseignant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="login">Login :</label>
                                        <input type="text" name="login" id="login" value="<?= htmlspecialchars($enseignant['loginEnseignant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="mdp">Mot de passe (laisser vide pour ne pas changer) :</label>
                                        <input type="password" name="mdp" id="mdp">
                                    </p>
                                    <p>
                                        <input type="submit" name="update_prof" value="Modifier">
                                    </p>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="right-section">
                <h2>Ajouter un enseignant :</h2>
                <form action="" method="POST" id="add_prof_form">
                    <p>
                        <label for="nom">Nom :</label>
                        <input type="text" name="nom" id="nom" required>
                    </p>
                    <p>
                        <label for="prenom">Prénom :</label>
                        <input type="text" name="prenom" id="prenom" required>
                    </p>
                    <p>
                        <label for="email">Email :</label>
                        <input type="email" name="email" id="email" required>
                    </p>
                    <p>
                        <label for="login">Login :</label>
                        <input type="text" name="login" id="login" required>
                    </p>
                    <p>
                        <label for="mdp">Mot de passe :</label>
                        <input type="password" name="mdp" id="mdp" required>
                    </p>
                    <p>
                        <input type="submit" name="add_prof" value="Ajouter">
                    </p>
                </form>
            </div>
        </div>
        <div class="admin-link">
        <a href="PageAdminEtudiant.php" class="btn">Gestion étudiants</a>
        </div>
    </div>
</body>
</html>
