<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/admin.css">
    <title>Admin - Gestion des étudiants</title>
</head>
<body>
    <h1>Gestion des étudiants</h1> <!-- Titre centré en haut -->

    <a href="deconnexion.php" class="logout">Se déconnecter</a>
    <?php
    session_start();
    // Afficher les erreurs pour le débogage
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    if ($_SESSION['authentification'] == false || $_SESSION['Permission'] < 4) {
        header('Location: Erreur.php');
        exit;
    }

    include("test.php");

    // Ajouter un étudiant
    if (isset($_POST['add_etudiant'])) {
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $login = $_POST['login'];
        $mdp = sha1($_POST['mdp']);

        // Vérification des données
        if (empty($nom) || empty($prenom) || empty($email) || empty($login) || empty($mdp)) {
            echo "Tous les champs sont obligatoires.";
        } else {
            $sqlInsertetudiant = "INSERT INTO SAE203_Etudiant (nomEtudiant, prenomEtudiant, mailEtudiant, loginEtudiant, mdpEtudiant)
                                  VALUES (:nom, :prenom, :email, :login, :mdp)";
            $insertetudiant = $db->prepare($sqlInsertetudiant);
            $result = $insertetudiant->execute(array(
                ':nom' => $nom,
                ':prenom' => $prenom,
                ':email' => $email,
                ':login' => $login,
                ':mdp' => $mdp
            ));
            
            if ($result) {
                echo "Etudiant ajouté avec succès.";
            } else {
                echo "Erreur lors de l'ajout de l'étudiant.";
            }
        }
    }

    // Modifier un étudiant
    if (isset($_POST['update_etudiant'])) {
        $id_etudiant = $_POST['id_etudiant'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $login = $_POST['login'];
        if (!empty($_POST['mdp'])) {
            $mdp = sha1($_POST['mdp']);
        } else {
            $mdp = null;
        }

        // Construire la requête SQL
        $sqlUpdateEtudiant = "UPDATE SAE203_Etudiant SET nomEtudiant = :nom, prenomEtudiant = :prenom, mailEtudiant = :email, loginEtudiant = :login";
        $params = array(
            ':nom' => $nom,
            ':prenom' => $prenom,
            ':email' => $email,
            ':login' => $login,
            ':id_etudiant' => $id_etudiant
        );
        if (!empty($mdp)) {
            $sqlUpdateEtudiant .= ", mdpEtudiant = :mdp";
            $params[':mdp'] = $mdp;
        }
        $sqlUpdateEtudiant .= " WHERE id_etudiant = :id_etudiant";

        // Préparer et exécuter la requête
        $sqlUpdateEtudiant = $db->prepare($sqlUpdateEtudiant);
        $result = $sqlUpdateEtudiant->execute($params);

        if ($result) {
            echo "Etudiant modifié avec succès.";
        } else {
            echo "Erreur lors de la modification de l'étudiant.";
        }
    }

    // Supprimer un étudiant et ses inscriptions associées
    if (isset($_POST['delete_etudiant'])) {
        $id_etudiant = $_POST['id_etudiant'];

        // Supprimer les inscriptions associées aux cours de l'étudiant
        $sqlDeleteInscriptions = "DELETE SAE203_Inscription FROM SAE203_Inscription JOIN SAE203_Cours ON SAE203_Inscription.cours_id = SAE203_Cours.id_cours WHERE SAE203_Inscription.etudiant_id = $id_etudiant";
        $deleteInscriptions = $db->prepare($sqlDeleteInscriptions);
        $deleteInscriptions->execute();

        // Supprimer l'étudiant
        $sqlDeleteetudiant = "DELETE FROM SAE203_Etudiant WHERE id_etudiant = :id_etudiant";
        $deleteetudiant = $db->prepare($sqlDeleteetudiant);
        $deleteetudiant->execute(array(':id_etudiant' => $id_etudiant));

        echo "Etudiant et ses inscriptions associées supprimés avec succès.";
    }

    // Récupérer la liste des étudiants
    $query = $db->prepare("SELECT * FROM SAE203_Etudiant");
    $query->execute();
    $enseignants = $query->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="container">
        <div class="content">
            <div class="left-section">
                <h2>Liste des étudiants :</h2>
                <ul>
                    <?php foreach ($enseignants as $enseignant): ?>
                        <li>
                            <?= htmlspecialchars($enseignant['prenomEtudiant'] . ' ' . $enseignant['nomEtudiant']); ?>
                            <form method="post" action="" style="display:inline;">
                                <input type="hidden" name="id_etudiant" value="<?= $enseignant['id_etudiant']; ?>">
                                <input type="submit" name="delete_etudiant" value="Supprimer">
                            </form>
                            <button onclick="document.getElementById('editForm-<?= $enseignant['id_etudiant']; ?>').style.display='block'">Modifier</button>
                            <div id="editForm-<?= $enseignant['id_etudiant']; ?>" style="display:none;">
                                <form method="post" action="">
                                    <input type="hidden" name="id_etudiant" value="<?= $enseignant['id_etudiant']; ?>">
                                    <p>
                                        <label for="nom">Nom :</label>
                                        <input type="text" name="nom" id="nom" value="<?= htmlspecialchars($enseignant['nomEtudiant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="prenom">Prénom :</label>
                                        <input type="text" name="prenom" id="prenom" value="<?= htmlspecialchars($enseignant['prenomEtudiant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="email">Email :</label>
                                        <input type="email" name="email" id="email" value="<?= htmlspecialchars($enseignant['mailEtudiant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="login">Login :</label>
                                        <input type="text" name="login" id="login" value="<?= htmlspecialchars($enseignant['loginEtudiant']); ?>" required>
                                    </p>
                                    <p>
                                        <label for="mdp">Mot de passe (laisser vide pour ne pas changer) :</label>
                                        <input type="password" name="mdp" id="mdp">
                                    </p>
                                    <p>
                                        <input type="submit" name="update_etudiant" value="Modifier">
                                    </p>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="right-section">
                <h2>Ajouter un étudiant :</h2>
                <form action="" method="POST" id="add_etudiant_form">
                    <p>
                        <label for="nom">Nom :</label>
                        <input type="text" name="nom" id="nom" required>
                    </p>
                    <p>
                        <label for="prenom">Prénom :</label>
                        <input type="text" name="prenom" id="prenom" required>
                    </p>
                    <p>
                        <label for="email">Email :</label>
                        <input type="email" name="email" id="email" required>
                    </p>
                    <p>
                        <label for="login">Login :</label>
                        <input type="text" name="login" id="login" required>
                    </p>
                    <p>
                        <label for="mdp">Mot de passe :</label>
                        <input type="password" name="mdp" id="mdp" required>
                    </p>
                    <p>
                        <input type="submit" name="add_etudiant" value="Ajouter">
                    </p>
                </form>
            </div>
        </div>
        <a href="pageAdmin.php"><button>Retour</button></a> <!-- Bouton de retour -->
    </div>
    
</body>
</html>
