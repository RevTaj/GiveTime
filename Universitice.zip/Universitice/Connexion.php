<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 
include("test.php");

$login = strip_tags($_POST['login']);
$mdp = strip_tags($_POST['mdp']);

if (!empty($login) && !empty($mdp)) {
    $User = $db->prepare("SELECT loginEtudiant,mdpEtudiant,id_etudiant FROM SAE203_Etudiant WHERE loginEtudiant=? AND mdpEtudiant=?");
    $User->execute([$login, sha1($mdp)]);
    $test = $User->fetch();

    if (!empty($test)) {
        session_start();
        $_SESSION['login'] = $login;
        $_SESSION['authentification'] = true;
        $_SESSION['Permission'] = 2;
        $_SESSION['Identifiant'] = $test['id_etudiant'];
        $_SESSION['date'] = date("Y-m-d");
        header('location: page1.php');
    }else {
        header('location: index.php?msg="Erreur de login / Erreur de mot de passe"');
    }
}
/*
if (isset($login) && isset($mdp)) {
    $User = $db->prepare("SELECT loginEtudiant,mdpEtudiant FROM SAE203_Etudiant WHERE loginEtudiant=? AND mdpEtudiant=?");
    $User->execute([$login, sha1($mdp)]);
    $test = $User->fetch();

    if ($test) {
        session_start();
        $_SESSION['login'] = $login;
        $_SESSION['authentification'] = true;
        $_SESSION['ID'] = 3; // Par défaut l'id = 1 donc n+1 pour chaque rôle. 
        $_SESSION['date'] = date("Y-m-d");
        header('location: page1.php');
    }else {
        header('location: index.php?msg="Erreur de login / Erreur de mot de passe"');
    }
}*/

?>
</body>
</html>
